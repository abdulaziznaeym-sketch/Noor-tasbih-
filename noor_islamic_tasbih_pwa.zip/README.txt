NOOR - Islamic Tasbih (PWA)

Files:
- index.html: app
- manifest.json: installable app settings
- service-worker.js: offline cache
- icon.svg: app icon

To install on iPhone:
1. Upload all four files to the same folder on an HTTPS host (GitHub Pages works).
2. Open the published website in Safari.
3. Tap Share > Add to Home Screen > Add.

Important:
- This is a free installable website/PWA, not an App Store IPA.
- Service worker/offline support requires HTTPS or localhost.
- The included dua text is a starter collection. Verify full Arabic text, transliteration,
  meanings and references with reliable Islamic sources before relying on it for worship.
